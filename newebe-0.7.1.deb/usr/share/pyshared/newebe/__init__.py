# Base Newebe Module
