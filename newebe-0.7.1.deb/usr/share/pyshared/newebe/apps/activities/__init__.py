'''
Activity module provide services and utilities to manage user activities and
contact activities.
'''
