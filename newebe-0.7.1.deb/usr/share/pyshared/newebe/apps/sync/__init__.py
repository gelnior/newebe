'''
Handlers to manage data synchronization with contacts.
'''
