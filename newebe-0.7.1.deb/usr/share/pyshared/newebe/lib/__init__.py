'''
Tools to facilitate application development for newebe.
'''
