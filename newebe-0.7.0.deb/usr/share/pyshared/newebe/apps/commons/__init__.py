'''
Pictures module : handle picture posting and sharing.
'''
