'''
Platform module handles user profile and contacts management.
'''
