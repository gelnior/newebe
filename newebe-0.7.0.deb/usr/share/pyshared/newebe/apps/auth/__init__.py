'''
Handlers related to authentication (login, logout, registering...)
'''
