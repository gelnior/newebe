'''
Handlers and models for contact management.
'''
