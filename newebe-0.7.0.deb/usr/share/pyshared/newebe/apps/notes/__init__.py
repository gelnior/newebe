'''
Notes module provides utility methods and services to
access to notes written by newebe owner or notes
published by contacts.
'''

__all__ = ["handlers", "models"]
