'''
This module gives features for micro blogging.
'''
