# News limit describes the number of news returned by News resource.
NEWS_LIMIT = 10
